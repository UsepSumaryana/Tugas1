<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Siswa extends Model
{
    //
    public $primaryKey = 'nis';

    protected $table = 't_siswa';

    protected $fillable = [
    	'nis', 'nama_lengkap', 'jenis_kelamin', 'alamat', 'no_telp', 'id_kelas', 'foto'
    ];

    public function getJenisKelaminDisplayAttribute()
    {
    	if (@$this->attributes['jenis_kelamin'] == 'L') return 'Laki-Laki';
    	if (@$this->attributes['jenis_kelamin'] == 'P') return 'Perempuan';
    }

    public function kelas()
    {
    	return $this->hasOne('\App\kelas', 'id_kelas', 'id_kelas');
    }
}
